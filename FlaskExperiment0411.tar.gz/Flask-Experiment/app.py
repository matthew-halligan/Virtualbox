from flask import Flask, render_template, flash, request, redirect, url_for, send_from_directory
import subprocess
import os
import jinja2
from werkzeug.utils import secure_filename

UPLOAD_FOLDER='/tmp/uploads'
ALLOWED_EXTENSIONS = {"tar.gz"}
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


current_tasks = {}

def allowed_file(filename):
    return True
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def add_to_task_map(id, tarball):
    current_tasks[id] = [tarball]

def get_task_map_id(id):
    return current_tasks[id]

@app.route('/download', methods=["POST", "GET"])
def download_file():
    if request.method=="POST":
        id = request.form["id"]
        session_path = os.path.join(app.config["UPLOAD_FOLDER"], id)
        name = "TPCP-Ubuntu20.tar.gz.am"
        return send_from_directory(session_path, name, as_attachment=True)

@app.route('/transform', methods=["POST", "GET"])
def transformation_on_file():
    if request.method=="POST":
        id = request.form["id"]
        transform = request.form["transform"]
        task = get_task_map_id(id)
        subprocess.call(f"./{transform}.sh", shell=True)
        return f"Running {transform} on {id}"

@app.route('/', methods=["POST", "GET"])
def upload_file():
    global current_tasks
    current_series_ids = sorted(os.listdir(app.config['UPLOAD_FOLDER']))

    current_tasks_temp = {}
    for key in current_tasks.keys():
        if key in current_series_ids:
            current_tasks_temp[key] = current_tasks[key]
    current_tasks = current_tasks_temp

    if request.method == 'POST':
        print("POST")
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            print("No file part")
            return redirect(request.url)
        file = request.files['file']
        # If the user does not select a file, the browser submits an
        # empty file without a filename.
        if file.filename == '':
            print("No Filename")
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            if len(current_series_ids) > 0:
                id = str(int(current_series_ids[-1])+1)
            else:
                id = "1"
            session_path = os.path.join(app.config['UPLOAD_FOLDER'], id)
            os.mkdir(session_path)
            file.save(os.path.join(session_path, filename))
            add_to_task_map(id, filename)
            return render_template("index.html", id=id, current_series_ids=sorted(os.listdir(app.config['UPLOAD_FOLDER'])), current_tasks=current_tasks)

    return render_template("index.html", current_series_ids=current_series_ids, current_tasks=current_tasks)

@app.route('/a', methods=["POST"])
def hello_world2():
    subprocess.call("./test.sh", shell=True)
    return render_template("click.html")

#@app.route('/', methods=["POST", "GET"])
#def upload():
#    if request.method == 'POST':
#        f = request.files['file']
#        f.save(secure_filename(f.filename))
 #       return 'file uploaded successfully'

if __name__ == '__main__':
    app.run()
